/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Version3;

import java.util.Arrays;

/**
 *
 * @author Student.Admin
 */
public class V3TMain {

    public static void main(String[] args) {
        EmployeeRooster er = new EmployeeRooster();
          er.CountHourlyEmployee();
//        er.CountCommissionEmployee();
//        er.CountBasePlusCommissionEmployee();
//        er.PieceWorkerEmployee();
//        er.DisplayAllEmployee();
          er.DisplayHE();
//        er.DisplayCE();
//        er.DisplayBPCE();
//        er.DisplayPWE();
//        er.removeEmployee();
//        er.addEmployee();

    }

}
